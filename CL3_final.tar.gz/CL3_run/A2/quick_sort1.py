import xml.etree.ElementTree as X

def qsort_handler(array, low, high):
	qsort(array, low, high)
	return array

def partition(array,low,high):
	pivot=array[low]
	left=low+1
	right=high
	while(left<=right):
		if(array[left]<pivot and left<=high):
			left=left+1
		if(array[right]>pivot):
			right=right-1
		if(left<right):
			temp=array[left]
			array[left]=array[right]
			array[right]=temp
	temp=array[low]
	array[low]=array[right]
	array[right]=temp
	return right
def qsort(array, low, high):
	if low<high:
		p = partition(array, low, high)
		qsort(array, low, p-1)
		qsort(array, p+1, high)
	#t1.start()
	#t2.start()
	#t1.join()
	#t2.join()
		
r = X.parse('input.xml').getroot()
array = map(int, r.text.split())
#print "INPUT ARRAY = ",array
qsort_handler(array, 0, len(array)-1)
print "SORTED ARRAY = "
for i in array:
	print i
